package com.example.bobby.udr;

public class Playlistviewaudio {
    private String playlistname;

    public Playlistviewaudio() {
    }

    public Playlistviewaudio(String playlistname) {
        this.playlistname = playlistname;

    }

    public String getPlaylistname() {
        return playlistname;
    }

    public void setPlaylistname(String playlistname) {
        this.playlistname = playlistname;
    }


}
