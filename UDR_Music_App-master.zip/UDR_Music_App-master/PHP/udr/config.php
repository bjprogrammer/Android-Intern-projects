<?php
define("DB_HOST", "fdb14.biz.nf");
define("DB_USER", "2104393_bj");          
define("DB_PASSWORD", "Bobby1993#");      
define("DB_DATABASE", "2104393_bj");      
define("GOOGLE_API_KEY", "AIzaSyDMnunAT4i2zhsYCDILBfpG3dqlDlCMw58"); // Place your Google API Key
define("GOOGLE_API_URL","https://gcm-http.googleapis.com/gcm/send");
define("PWD", "./");
?>